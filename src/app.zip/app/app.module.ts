import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home/home.component';
import { HomeNameComponent } from './components/home/home-name/home-name.component';
import { AboutComponente } from './components/about/about/about.component';
import { AboutPerfilComponent } from './components/about/about-perfil/about-perfil.component';
import { AboutExperienceComponent } from './components/about/about-experience/about-experience.component';
//INICIO SERVICE
import { CargarScriptsService } from './services/cargar-scripts.service';
import { PortafolioComponent } from './components/portafolio/portafolio/portafolio.component';
import { PortafolioProyectoComponent } from './components/portafolio/portafolio-proyecto/portafolio-proyecto.component';
import { LanguageComponent } from './components/language/language/language.component';
//CONNECTORS
import { AboutComponent } from './connectors/about/about.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HomeNameComponent,
    AboutComponent,
    AboutPerfilComponent,
    AboutExperienceComponent,
    PortafolioComponent,
    PortafolioProyectoComponent,
    LanguageComponent,
    AboutComponente
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([
      {path:'home',component:HomeComponent},
      {path:'about',component:AboutComponente},
      {path:'portafolio',component:PortafolioComponent},
      {path: '', redirectTo: '/home', pathMatch: 'full' },
      //{path: '**', component:VistaErrorComponent}
    ])
  ],
  providers: [
    CargarScriptsService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
