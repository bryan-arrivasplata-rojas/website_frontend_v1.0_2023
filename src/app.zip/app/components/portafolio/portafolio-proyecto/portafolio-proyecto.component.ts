import { Component } from '@angular/core';

@Component({
  selector: 'app-portafolio-proyecto',
  templateUrl: './portafolio-proyecto.component.html',
  styleUrls: ['./portafolio-proyecto.component.scss']
})
export class PortafolioProyectoComponent {

}
