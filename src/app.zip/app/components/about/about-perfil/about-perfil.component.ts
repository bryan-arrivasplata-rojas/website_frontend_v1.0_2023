import { Component } from '@angular/core';

@Component({
  selector: 'app-about-perfil',
  templateUrl: './about-perfil.component.html',
  styleUrls: ['./about-perfil.component.scss']
})
export class AboutPerfilComponent {

}
