import { Component } from '@angular/core';

@Component({
  selector: 'app-about-experience',
  templateUrl: './about-experience.component.html',
  styleUrls: ['./about-experience.component.scss']
})
export class AboutExperienceComponent {

}
